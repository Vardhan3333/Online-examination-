package com.example.Online.Examination.System;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
 
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
 
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .authorizeRequests()
                .antMatchers("/restrictedPage.jsp").hasRole("USER") // Configure the restricted JSP page
                .anyRequest().permitAll()
            .and()
            .formLogin()
                // Your form login configurations...
            .and()
            .sessionManagement()
                .maximumSessions(1).maxSessionsPreventsLogin(true); // Allow only one session
    }
}
