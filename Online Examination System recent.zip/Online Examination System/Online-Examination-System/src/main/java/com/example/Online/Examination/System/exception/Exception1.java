package com.example.Online.Examination.System.exception;

public class Exception1 extends RuntimeException {
	
	public Exception1(String message) {
		super(message);
	}

	

}
