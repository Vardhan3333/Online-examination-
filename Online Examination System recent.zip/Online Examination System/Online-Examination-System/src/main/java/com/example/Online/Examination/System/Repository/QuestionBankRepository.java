package com.example.Online.Examination.System.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Online.Examination.System.Model.QuestionBank;

public interface QuestionBankRepository extends JpaRepository<QuestionBank, Long> {

}
