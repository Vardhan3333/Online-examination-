package com.example.Online.Examination.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineExaminationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
